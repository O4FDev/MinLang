#ifndef MINYAR_FREESTANDING_STRING_H
#define MINYAR_FREESTANDING_STRING_H
#include <stddef.h>
void *memcpy(void *restrict destination, const void *restrict source, size_t count);
void *memmove(void *destination, const void *source, size_t count);
void *memset(void *destination, int value, size_t count);
int memcmp(const void *left, const void *right, size_t count);
size_t strlen(const char *text);
int strcmp(const char *left, const char *right);
void *memchr(const void *data, int value, size_t count);
char *strchr(const char *text, int character);
#endif
