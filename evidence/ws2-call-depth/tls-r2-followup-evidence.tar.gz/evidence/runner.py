from pathlib import Path
import hashlib,json,platform,runpy,shutil,subprocess,sys,tarfile,traceback
root=Path.cwd()
out=root/'evidence'
out.mkdir(exist_ok=True)
expected=json.loads((root/'input-manifest.json').read_text())
actual={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in expected['source_sha256']}
assert actual==expected['source_sha256'], 'isolated TLS input differs from exported snapshot'
assert not (root/'runtime/minyar_calldepth.h').exists(), 'recovery must not enter the TLS follow-up'
archive=Path('/tmp/ws2-tls-r2-input.tar.gz')
shutil.copy2(Path(__file__),out/'runner.py')
report={**expected,'runner_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'status':'running','actual_source_sha256':actual,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'platform':platform.uname()._asdict(),'commands':[]}
original_run=subprocess.run
def save(): (out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
def capture(command,*args,**kwargs):
    index=len(report['commands'])
    row={'argv':list(map(str,command)),'cwd':str(root)}
    tool=Path(shutil.which(str(command[0])) or command[0]).resolve()
    if tool.is_file(): row['executable_sha256']=hashlib.sha256(tool.read_bytes()).hexdigest()
    stdin=kwargs.get('input')
    if stdin is not None:
        data=stdin.encode() if isinstance(stdin,str) else stdin
        name=f'{index:02d}-input.c'; (out/name).write_bytes(data)
        row['stdin_file']=name;row['stdin_sha256']=hashlib.sha256(data).hexdigest()
    result=original_run(command,*args,**kwargs)
    row.update(status=result.returncode,stdout=result.stdout,stderr=result.stderr)
    if '-o' in command:
        binary=Path(command[command.index('-o')+1])
        if binary.is_file():
            row['output_binary_sha256']=hashlib.sha256(binary.read_bytes()).hexdigest()
            shutil.copy2(binary,out/f'{index:02d}-depth-binary')
    report['commands'].append(row);save()
    return result
save()
try:
    version=original_run(['clang','--version'],capture_output=True,text=True,timeout=30)
    report['clang_version']=version.stdout
    subprocess.run=capture
    sys.path.insert(0,str(root/'tests'))
    sys.argv=[str(root/'tests/thread-config.py')]
    try:runpy.run_path(str(root/'tests/thread-config.py'),run_name='__main__')
    except SystemExit as exited:
        report['status']='passed' if exited.code==0 else 'failed';report['test_exit_status']=exited.code
except BaseException as error:
    report['status']='failed';report['error']=str(error);traceback.print_exc()
finally:
    subprocess.run=original_run;save()
    with tarfile.open('/tmp/ws2-tls-r2-evidence.tar.gz','w:gz') as t:
        for p in sorted(root.rglob('*')):
            if p.is_file() and '__pycache__' not in p.parts:t.add(p,arcname=str(p.relative_to(root)))
print(report['status'],len(report['commands']),'exact commands',flush=True)
raise SystemExit(0 if report['status']=='passed' else 1)
